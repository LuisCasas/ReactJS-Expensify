import React from 'react';

const ExpenseDashboardPage = () => (
    <div>
        This is a dashboard component.
    </div>
);

export default ExpenseDashboardPage;