import React from 'react';

const HelpPage = () => (
    <div>
        Add a Help page.
    </div>
);

export default HelpPage;