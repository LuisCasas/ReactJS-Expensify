import React from 'react';

const AddExpensePage = () => (
    <div>
        Add a Help page.
    </div>
);

export default AddExpensePage;